import React from 'react';
const About = () => {
  return (
    <div>
      This is about an component
      <p>Social media or social networking sites are now part of our routine. People wake up and open their accounts to follow their news, 
        friends and family life or to create content. Although social media is not the only communication channel, they become more relevant   
        for   sharing   of tourism   experience, which   includes   not only knowledge-related aspects   such as facts about holiday   attributes
        (e.g.  prices, weather conditions, hotels, route, places and other attractions) but may additionally include communicating emotions, 
        imaginations and fantasies about features of   a   holiday, for example through photographs, emoticons   and   other linguistic markers 
        in online communication. Social media have played a major role as a platform for   personal travel story reviews, warnings, advice/tips, 
        and   recommendations which inﬂuence trip decisions and even create pre trip destination impressions. Past visitors’ positive experiences 
        and stories are genuine third-party contributions which may encourage others to visit. The   users   of that website can share 
        travel-related   information, stories and   experiences uploading text contents, images, audios, and videos without any special 
        technical skills as well as their travel-related comments, opinions, reviews and ratings, and recommendations, which   is termed 
        user-generated content. That user-generated travel reviews are useful for travelers when deciding where to   go (destination), where to   
        stay (accommodation) and what to do at the destination (activities).
        
        The travel experience sharing website is a web-based application and maintain all data or experiences by travelers. The objective of this 
        project is to design a website that help people to plan their trips or tours. The purpose is to design a website using which one can gives 
        all the information related to travel.
        </p>
    </div>
  );
}

export default About;

